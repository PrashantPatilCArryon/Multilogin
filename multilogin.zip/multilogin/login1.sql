﻿CREATE TABLE [dbo].[Table]
(
	[Username] VARCHAR(50) NOT NULL PRIMARY KEY, 
    [Password] VARCHAR(50) NULL, 
    [Type] VARCHAR(50) NULL
)
