﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace multilogin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-IDDVHGL;Initial Catalog=login;Integrated Security=True;");
            SqlDataAdapter sqa = new SqlDataAdapter("select Count(*) from login1 where Username='" + textBox1.Text + "' and Password='" + textBox2.Text + "' and Type= '" + comboBox1.Text +"'", con);
            DataTable dt = new DataTable();
            sqa.Fill(dt);
            if(dt.Rows[0][0].ToString() == "1")
            {
                SqlDataAdapter sqa1 = new SqlDataAdapter("select Type from login1 where Username='" + textBox1.Text + "' and Password='" + textBox2.Text + "'", con);
                DataTable dt1 = new DataTable();
                sqa1.Fill(dt1);
                 if(dt1.Rows[0][0].ToString() =="SERVER")
                 {
                     this.Hide();
                     server ss = new server(textBox1.Text);
                     ss.Show();
                 }
                if(dt1.Rows[0][0].ToString() =="CLIENT")
                {
                    this.Hide();
                    client ss1 = new client(textBox1.Text);
                    ss1.Show();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
