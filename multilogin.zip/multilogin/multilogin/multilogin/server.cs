﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace multilogin
{
    public partial class server : Form
    {
        public server(String user)
        {
            InitializeComponent();
            label2.Text = "USER " + user;
        }
    }
}
